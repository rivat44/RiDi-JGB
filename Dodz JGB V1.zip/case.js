/*
– Heloo, Tq Udah Make Script Ini >_<
# Recode By Dodz
# Base By YannRzy.
*/

// ─────「 SET MODULE 」───── \\
require("./settings");
const {
  default: makeWaSocket,
  socket,
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  downloadContentFromMessage,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType,
} = require("@whiskeysockets/baileys");
const { modul } = require("./lib/module");
const { exec } = require("child_process");
const { axios, baileys, chalk, cheerio, FileType, ffmpeg, PhoneNumber, process, moment, ms, util, ytdl,  } = modul;
const os = require('os');
const speed = require('performance-now')
const sharp = require('sharp');
const { color, bgcolor } = require("./lib/color");
const { delay } = require("@whiskeysockets/baileys");
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const path = require("path");
const fs = require('fs')
let antilink = JSON.parse(fs.readFileSync('./database/antilink.json'))

module.exports = conn = async (conn, m, chatUpdate, store) => {
try {
async function appenTextMessage(text, chatUpdate) {
let messages = await generateWAMessage(
m.chat,
{
text: text,
mentions: m.mentionedJid,
},
{
userJid: conn.user.id,
quoted: m.quoted && m.quoted.fakeObj,
},
);
messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id);
messages.key.id = m.key.id;
messages.pushName = m.pushName;
if (m.isGroup) messages.participant = m.sender;
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: "append",
};
conn.ev.emit("messages.upsert", msg);
}
const { type, quotedMsg, mentioned, now, fromMe } = m;
let body =
m.mtype === "interactiveResponseMessage"
? JSON.parse(
m.message.interactiveResponseMessage.nativeFlowResponseMessage
.paramsJson,
).id
: m.mtype === "conversation"
? m.message.conversation
: m.mtype == "imageMessage"
? m.message.imageMessage.caption
: m.mtype == "videoMessage"
? m.message.videoMessage.caption
: m.mtype == "extendedTextMessage"
? m.message.extendedTextMessage.text
: m.mtype == "buttonsResponseMessage"
? m.message.buttonsResponseMessage.selectedButtonId
: m.mtype == "listResponseMessage"
? m.message.listResponseMessage.singleSelectReply
.selectedRowId
: m.mtype == "templateButtonReplyMessage"
? m.message.templateButtonReplyMessage.selectedId
: m.mtype == "messageContextInfo"
? m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply
.selectedRowId ||
m.text
: m.mtype === "editedMessage"
? m.message.editedMessage.message.protocolMessage
.editedMessage.extendedTextMessage
? m.message.editedMessage.message.protocolMessage
.editedMessage.extendedTextMessage.text
: m.message.editedMessage.message.protocolMessage
.editedMessage.conversation
: "";


// ─────「 SET FILE 」───── \\
const {
clockString,
parseMention,
formatp,
isUrl,
sleep,
runtime,
getBuffer,
jsonformat,
format,
capital,
reSize,
generateProfilePicture,
} = require("./lib/myfunc");

const premium = JSON.parse(fs.readFileSync("./database/premium.json"))

// ─────「 SET BOT - ADMIN - OWNER 」───── \\
const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const chath = body;
const pes = body;
const content = JSON.stringify(m.message);
const from = m.key.remoteJid;
const botNumber = await conn.decodeJid(conn.user.id);
const isCreator = m.sender === global.ownernumber.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
const pushname = m.pushName || "Nothing";
const text = (q = args.join(" "));
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || "";
const qmsg = quoted.msg || quoted;
const isMedia = /image|video|sticker|audio/.test(mime);
const isImage = type == "imageMessage";
const isVideo = type == "videoMessage";
const isAudio = type == "audioMessage";
const isSticker = type == "stickerMessage";
const isQuotedImage =
type === "extendedTextMessage" && content.includes("imageMessage");
const isQuotedLocation =
type === "extendedTextMessage" && content.includes("locationMessage");
const isQuotedVideo =
type === "extendedTextMessage" && content.includes("videoMessage");
const isQuotedSticker =
type === "extendedTextMessage" && content.includes("stickerMessage");
const isQuotedAudio =
type === "extendedTextMessage" && content.includes("audioMessage");
const isQuotedContact =
type === "extendedTextMessage" && content.includes("contactMessage");
const isQuotedDocument =
type === "extendedTextMessage" && content.includes("documentMessage");
const sender = m.isGroup
? m.key.participant
? m.key.participant
: m.participant
: m.key.remoteJid;
const senderNumber = sender.split("@")[0];
const isGroup = from.endsWith('@g.us')
const groupMetadata = m.isGroup
? await conn.groupMetadata(m.chat).catch((e) => {})
: "";
const participants =
m.isGroup && groupMetadata ? groupMetadata.participants : [];
const groupAdmins = m.isGroup
? await participants.filter((v) => v.admin !== null).map((v) => v.id)
: [];
const groupName = m.isGroup && groupMetadata ? groupMetadata.subject : [];
const groupOwner = m.isGroup && groupMetadata ? groupMetadata.owner : [];
const groupMembership =
m.isGroup && groupMetadata ? groupMetadata.membership : [];
const groupMembers =
m.isGroup && groupMetadata ? groupMetadata.participants : [];
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
const isPremium = premium.includes(m.sender)
const mentionUser = [
...new Set([
...(m.mentionedJid || []),
...(m.quoted ? [m.quoted.sender] : []),
]),
];
const mentionByTag =
type == "extendedTextMessage" &&
m.message.extendedTextMessage.contextInfo != null
? m.message.extendedTextMessage.contextInfo.mentionedJid
: [];
const mentionByReply =
type == "extendedTextMessage" &&
m.message.extendedTextMessage.contextInfo != null
? m.message.extendedTextMessage.contextInfo.participant || ""
: "";
const numberQuery =
q.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net";
const usernya = mentionByReply ? mentionByReply : mentionByTag[0];
const Input = mentionByTag[0]
? mentionByTag[0]
: mentionByReply
? mentionByReply
: q
? numberQuery
: false;

// ─────「 CONSOLE 」───── \\
if (isCmd) {
const from = m.key.remoteJid
const chatType = from.endsWith("@g.us") ? "Group" : "Private"
console.log(
chalk.blue.bold("Messages Detected 🚀"), 
chalk.white.bold("\n▢ Command :"), chalk.white.bold(`${prefix+command}`), 
chalk.white.bold("\n▢ Pengirim :"), chalk.white.bold(`${sender}`), 
chalk.white.bold("\n▢ Name :"), chalk.white.bold(`${pushname}`), 
chalk.white.bold("\n▢ Chat Type :"), chalk.white.bold(`${chatType}\n\n`)
   )
}

// ─────「 SET REPLY 」───── \\
async function reply(teks) {
conn.sendMessage(m.chat, {
text: teks,
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 9999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: `${global.idch}`,
newsletterName: `${global.newslettername}`
}
}
}, {
quoted: m
})
}

 //menghapus statusMention di Group
if (m.mtype.includes("groupStatusMentionMessage") && m.isGroup) {
await conn.deleteMessage(m.chat, m.key);
}

// ─────「 ALL FUNCTION 」───── \\
  // Function Public / Self
if (!conn.public && !m.key.fromMe && !global.ownernumber.includes(m.sender.split("@")[0])) {
return;
}

  // Function DellCase
async function dellCase(filePath, caseNameToRemove) {
fs.readFile(filePath, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan:', err);
return;
}

const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
const modifiedData = data.replace(regex, '');
fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return;
}

console.log(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
});
});
}

// ─────「 PLUGINS LOADER 」───── \\
const pluginsLoader = async (directory) => {
let plugins = [];
const folders = fs.readdirSync(directory);
folders.forEach((file) => {
const filePath = path.join(directory, file);
if (filePath.endsWith(".js")) {
try {
const resolvedPath = require.resolve(filePath);
if (require.cache[resolvedPath]) {
delete require.cache[resolvedPath];
}
const plugin = require(filePath);
plugins.push(plugin);
} catch (error) {
console.log(`Error loading plugin at ${filePath}:`, error);
}
}
});
return plugins;
};

let pluginsDisable = true;
const plugins = await pluginsLoader(path.resolve(__dirname, "plugins"));
const base = { conn, prefix, command, reply, text, isGroup: m.isGroup, isCreator, sender, senderNumber, pushname, args, runtime, formatp, sleep, getBuffer, isBotAdmins, isAdmins, isPremium };
for (let plugin of plugins) {
if (plugin.command.find((e) => e == command.toLowerCase())) {
pluginsDisable = false;
if (typeof plugin !== "function") return;
await plugin(m, base);
}
}
if (!pluginsDisable) return;
  
  // 🔥 Cek Link Grup kalau AntiLink aktif
if (m.isGroup && antilink[m.chat]) {
    let regex = /(https?:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+)/i
    if (regex.test(body)) {
        if (!isAdmins && !isOwner) {
            await conn.sendMessage(m.chat, { text: `🚫 Link Grup terdeteksi!\n\n@${m.sender.split("@")[0]}, pesanmu dihapus.`, mentions: [m.sender] })
            await conn.sendMessage(m.chat, { delete: m.key })
        }
    }
}

// ─────「 CASE COMMAND 」───── \\
switch (command) {
case "allmenu":
case "help":{
let mbut = `
Hi, @${sender.split("@")[0]}
I am ${global.namabot}, created using the Javascript language type commonjs, I was developed by ${global.ownername}

*──≡ Information*
▢ Nama : ${pushname}
▢ Tag : @${sender.split("@")[0]}
▢ Status : ${conn.public ? "Public" : "Self"}
▢ Owner : @${global.ownernumber}

*──「 Plugins Feature 」──*
▢ ${prefix}clearsession
▢ ${prefix}addplugins
▢ ${prefix}delplugins
▢ ${prefix}getplugins
▢ ${prefix}listplugin
▢ ${prefix}saveplugins

*──「 Case Feature 」──*
▢ ${prefix}self
▢ ${prefix}public
▢ ${prefix}runtime
▢ ${prefix}ping
▢ ${prefix}hidetag
▢ ${prefix}kick
`
conn.sendMessage(m.chat, {
document: fs.readFileSync("./package.json"),
fileName: `${global.namabot}`,
mimetype: "application/pdf",
fileLength: 99999,
pageCount: 666,
caption: mbut,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
forwardedNewsletterMessageInfo: {
newsletterName: `${global.newslettername}`,
newsletterJid: `${global.idch}`,
},
externalAdReply: {  
title: "Sewa Bot/ Beli Script? PV Owner :3", 
body: global.foother,
thumbnailUrl: global.thumbnail,
sourceUrl: global.website, 
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: m })
};
break

 //================== Owner Features ==================//
case 'self': {
if (!isCreator) return reply(mess.owner)
conn.public = false
reply('*Sukses Change To Self Mode*')
}
break

case 'public': {
if (!isCreator) return reply(mess.owner)
conn.public = true
reply('*Sukses Change To Public Mode*')
}
break

 //================== Group Freatures ==================//
case "runtime": {
let lowq = `*${global.namabot} Telah Online Selama:*\n${runtime(process.uptime(),)}*`;
m.reply(`${lowq}`);
}
break

case 'ping': {
const used = process.memoryUsage();
const cpus = os.cpus().map(cpu => {
cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
return cpu;
});

const cpu = cpus.reduce((last, cpu, _, { length }) => {
last.total += cpu.total;
last.speed += cpu.speed / length;
last.times.user += cpu.times.user;
last.times.nice += cpu.times.nice;
last.times.sys += cpu.times.sys;
last.times.idle += cpu.times.idle;
last.times.irq += cpu.times.irq;
return last;
}, {
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0
}
});

let timestamp = speed();
let latensi = speed() - timestamp;
let neww = performance.now();
let oldd = performance.now();

let respon = `
*㆔ Response Speed:* ${latensi.toFixed(4)} _Second_  
ㆳ ${(oldd - neww).toFixed(2)} _Milliseconds_  
ㆳ *Runtime:* ${runtime(process.uptime())}

┌───────────────── •
│ *Info Server ㇀*  
│ *RAM:* ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}
└───────────────── •

ㇴ *NodeJS Memory Usage*  
${Object.keys(used)
.map((key, _, arr) => `> ${key.padEnd(Math.max(...arr.map(v => v.length)), ' ')}: ${formatp(used[key])}`)
.join('\n')}

${cpus[0] ? `ㆫ *Total CPU Usage*  
\`${cpus[0].model.trim()} (${cpu.speed} MHz)\`
${Object.keys(cpu.times)
.map(type => `> *${(type + '*').padEnd(6)} : ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`)
.join('\n')}

ㇴ *CPU Core(s) Usage (${cpus.length} Core CPU)*  
${cpus
.map(
(cpu, i) => `> [ ${i + 1} ] ${cpu.model.trim()} (${cpu.speed} MHz)  
${Object.keys(cpu.times)
.map(type => `- *${(type + '*').padEnd(6)} : ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`)
.join('\n')}`
)
.join('\n\n')}` : ''}
`;

m.reply(respon);
}
break

case "h":
case "hidetag": {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins && !isCreator) return reply(mess.admin)
if (m.quoted) {
conn.sendMessage(m.chat, {
forward: m.quoted.fakeObj,
mentions: participants.map(a => a.id)
})
}
if (!m.quoted) {
conn.sendMessage(m.chat, {
text: q ? q : '',
mentions: participants.map(a => a.id)
}, { quoted: m })
}
}
break

case 'kick': case 'dor': {
if (!isGroup) return reply(mess.group)
if (!isCreator && !isAdmins) return reply(mess.admin)
if (!isBotAdmins) return reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await conn.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("*Nomor tidak terdaftar di whatsapp*")
const res = await conn.groupParticipantsUpdate(m.chat, [input], 'remove')
await reply(`*Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini*`)
} else {
return reply("@tag/reply")
}
}
break

// ====== AntiLink Command ======
case 'antilink': {
    if (!isAdmins && !isCreator) return m.reply('*⚠️ Fitur ini khusus Admin!*')
    if (args.length < 1) return m.reply('*Gunakan: /antilink on atau /antilink off*')

    if (args[0] === 'on') {
        antilink[m.chat] = true
        fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink, null, 2))
        m.reply('*✅ AntiLink diaktifkan untuk grup ini!*')
    } else if (args[0] === 'off') {
        delete antilink[m.chat]
        fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink, null, 2))
        m.reply('*❌ AntiLink dimatikan untuk grup ini!*')
    } else {
        m.reply('*Gunakan: /antilink on atau /antilink off*')
    }
}
break
// ─────「 BATAS CASE - EVAL 」───── \\
default:    
if (budy.startsWith('=>')) {
if (!isCreator) return

function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

}
} catch (err) {
console.log(util.format(err))
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
const fs = require('fs')
const chalk = require('chalk')

// ──「 Set Pairing 」── \\
global.pairingbot = '6285606661683' //nomor pairing
global.custompairing = 'DODZGNTG' //8 huruf no spasi

// ──「 Set Owner 」── \\
global.ownernumber = "6285606661683"
global.ownername = "Ripat OppiCiyal"
global.fother = "Ripat"

// ──「 Set Bot 」── \\
global.namabot = "RiDi - JGB"
global.botNumber = "6285606661683"
global.version = "1.0.0"
global.packname = "Created By Dodz"
global.author = "Ripat OppiCiyal"
global.foother = "Powered By Ripat"
global.newslettername = "© Ripat OppiCiyal [ @DodzBold ]"
global.idch = "120363333401130891@newsletter"

// ──「 Set Media 」── \\
global.website = "https://api-yannrzy-vy.vercel.app/"
global.thumbnail = "https://files.catbox.moe/hqzvvw.jpg"

// ──「 Set Message 」── \\
global.mess = {
    admin: '[ !! ] *sʏsᴛᴇᴍ*\nᴋʜᴜsᴜs ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ',
    botAdmin: '[ !! ] *sʏsᴛᴇᴍ*\nʙᴏᴛ ʙᴇʟᴜᴍ ᴊᴀᴅɪ ᴀᴅᴍɪɴ',
    owner: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ',
    group: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴀᴊᴀ',
    private: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ',
    premium: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ'
}



// *** message *** 
global.closeMsgInterval = 30; // 30 menit. maksimal 60 menit, minimal 1 menit
global.backMsgInterval = 2; // 2 jam. maksimal 24 jam, minimal 1 jam
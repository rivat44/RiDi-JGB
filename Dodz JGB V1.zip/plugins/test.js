let handler = async (m, { reply }) => {
// pedo
reply("oilah 😹")
}
handler.command = ["loli"]
module.exports = handler 
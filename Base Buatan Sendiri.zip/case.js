import settings from "./settings.js"
import { smsg } from "./lib/myfunc.js"

export default async function handler(sock, m) {
  const msg = smsg(sock, m)
  const prefix = settings.prefix
  const body = msg.body.startsWith(prefix) ? msg.body.slice(1).trim().split(" ")[0].toLowerCase() : null

  if (!body) return

  switch (body) {
    case "bot":
      await sock.sendMessage(msg.chat, { text: "*Online!*" }, { quoted: m })
      break

    case "menu":
      await sock.sendMessage(msg.chat, { text: `Hai, aku ${settings.botName}\n\nCommand:\n/ping\n/menu` }, { quoted: m })
      break
  }
}
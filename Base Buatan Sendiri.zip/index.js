import makeWASocket, { useMultiFileAuthState, makeCacheableSignalKeyStore } from "@whiskeysockets/baileys"
import pino from "pino"
import readline from "readline"
import settings from "./settings.js"
import handler from "./case.js"

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("session")

  const sock = makeWASocket({
    logger: pino({ level: "silent" }),
    printQRInTerminal: false, // disable QR
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" }))
    }
  })

  sock.ev.on("creds.update", saveCreds)

  // Cek apakah sudah login, kalau belum kasih pairing code
  if (!sock.authState.creds.registered) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
    rl.question("Masukkan nomor WhatsApp kamu (contoh: 628xxxx): ", async (phoneNumber) => {
      const code = await sock.requestPairingCode(phoneNumber)
      console.log(`Kode Pairing: ${code}`)
      rl.close()
    })
  }

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const m = messages[0]
    if (!m.message) return
    await handler(sock, m)
  })
}

startBot()
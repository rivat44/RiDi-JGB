export default {
  owner: ["6285606661683"], // nomor owner
  prefix: "/",          // prefix default
  botName: "DodzBot"
}